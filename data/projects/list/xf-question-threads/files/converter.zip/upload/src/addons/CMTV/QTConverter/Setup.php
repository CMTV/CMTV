<?php

namespace CMTV\QTConverter;

use XF\AddOn\AbstractSetup;
use XF\AddOn\StepRunnerInstallTrait;
use XF\AddOn\StepRunnerUninstallTrait;
use XF\AddOn\StepRunnerUpgradeTrait;

class Setup extends AbstractSetup
{
	use StepRunnerInstallTrait;
	use StepRunnerUpgradeTrait;
	use StepRunnerUninstallTrait;

    //
    // Converting forum types
    //
    public function installStep1()
    {
        $db = $this->db();

        // Converting "questions only" forums
        $db->update(
            'xf_forum',
            [
                'forum_type_id' => 'question',
                'type_config' => json_encode(['allow_answer_voting' => true, 'allow_downvote' => true])
            ],
            'CMTV_QT_type = ?', ['questions_only']
        );

        // Converting "thread and questions" forums
        $db->update(
            'xf_forum',
            [
                'forum_type_id' => 'discussion',
                'type_config' => json_encode(['allowed_thread_types' => ['question'], 'allow_answer_voting' => true, 'allow_downvote' => true])
            ],
            'CMTV_QT_type = ?', ['both']
        );
    }

    //
    // Converting best answers to questions
    //
    public function installStep2()
    {
        $db = $this->db();

        // Converting threads to questions
        $db->update(
            'xf_thread',
            [
                'discussion_type' => 'question',
                'type_data' => json_encode(['allow_question_actions' => 'yes'])
            ],
            'CMTV_QT_is_question = ?', [true]
        );

        $questions = $db->fetchAll("SELECT `thread_id` FROM `xf_thread` WHERE `CMTV_QT_is_question` = ?;", [true]);

        $db->beginTransaction();

        foreach ($questions as $question)
        {
            $db->insert(
                'xf_thread_question',
                [
                    'thread_id' => $question['thread_id']
                ],
                false,
                '`thread_id` = `thread_id`'
            );
        }

        $db->commit();

        // Converting best answers to solutions
        $bestAnswers = $db->fetchAll("SELECT `thread_id`, `post_id`, `post_user_id` FROM `xf_cmtv_qt_best_answer`;");

        $db->beginTransaction();

        foreach ($bestAnswers as $bestAnswer)
        {
            $db->update(
                'xf_thread',
                [
                    'type_data' => json_encode(['solution_post_id' => $bestAnswer['post_id'], 'solution_user_id' => $bestAnswer['post_user_id'], 'allow_question_actions' => 'yes'])
                ],
                'thread_id = ?', [$bestAnswer['thread_id']]
            );

            $db->insert(
                'xf_thread_question',
                [
                    'thread_id' => $bestAnswer['thread_id'],
                    'solution_post_id' => $bestAnswer['post_id'],
                    'solution_user_id' => $bestAnswer['post_user_id']
                ],
                false,
                "`solution_post_id` = {$bestAnswer['post_id']}, `solution_user_id` = {$bestAnswer['post_user_id']}"
            );
        }

        $db->commit();
    }

    //
    // Updating solved questions counters
    //
    public function installStep3()
    {
        $db = $this->db();
        $db->query("UPDATE `xf_user` SET `question_solution_count` = `CMTV_QT_best_answer_count`;");
    }
}