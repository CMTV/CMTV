Installation:

1. Move .bsp file into "Steam\SteamApps\common\Counter-Strike Source\cstrike\maps"

2. Launch game and click "Create Server". You will find my map in map-list.

GG!